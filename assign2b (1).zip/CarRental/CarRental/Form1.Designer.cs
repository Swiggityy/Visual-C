﻿namespace CarRental
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.rdBtnComp = new System.Windows.Forms.RadioButton();
			this.rdBtnMid = new System.Windows.Forms.RadioButton();
			this.rdBtnLux = new System.Windows.Forms.RadioButton();
			this.lblAge = new System.Windows.Forms.Label();
			this.lblDay = new System.Windows.Forms.Label();
			this.lblTotal = new System.Windows.Forms.Label();
			this.btnCalc = new System.Windows.Forms.Button();
			this.txtAge = new System.Windows.Forms.TextBox();
			this.txtDay = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// rdBtnComp
			// 
			this.rdBtnComp.AutoSize = true;
			this.rdBtnComp.Location = new System.Drawing.Point(69, 85);
			this.rdBtnComp.Name = "rdBtnComp";
			this.rdBtnComp.Size = new System.Drawing.Size(86, 17);
			this.rdBtnComp.TabIndex = 0;
			this.rdBtnComp.TabStop = true;
			this.rdBtnComp.Text = "Compact Car";
			this.rdBtnComp.UseVisualStyleBackColor = true;
			// 
			// rdBtnMid
			// 
			this.rdBtnMid.AutoSize = true;
			this.rdBtnMid.Location = new System.Drawing.Point(69, 108);
			this.rdBtnMid.Name = "rdBtnMid";
			this.rdBtnMid.Size = new System.Drawing.Size(84, 17);
			this.rdBtnMid.TabIndex = 1;
			this.rdBtnMid.TabStop = true;
			this.rdBtnMid.Text = "Mid-Size Car";
			this.rdBtnMid.UseVisualStyleBackColor = true;
			// 
			// rdBtnLux
			// 
			this.rdBtnLux.AutoSize = true;
			this.rdBtnLux.Location = new System.Drawing.Point(69, 131);
			this.rdBtnLux.Name = "rdBtnLux";
			this.rdBtnLux.Size = new System.Drawing.Size(75, 17);
			this.rdBtnLux.TabIndex = 2;
			this.rdBtnLux.TabStop = true;
			this.rdBtnLux.Text = "Luxury Car";
			this.rdBtnLux.UseVisualStyleBackColor = true;
			// 
			// lblAge
			// 
			this.lblAge.AutoSize = true;
			this.lblAge.Location = new System.Drawing.Point(25, 34);
			this.lblAge.Name = "lblAge";
			this.lblAge.Size = new System.Drawing.Size(76, 13);
			this.lblAge.TabIndex = 3;
			this.lblAge.Text = "Enter your age";
			// 
			// lblDay
			// 
			this.lblDay.AutoSize = true;
			this.lblDay.Location = new System.Drawing.Point(25, 59);
			this.lblDay.Name = "lblDay";
			this.lblDay.Size = new System.Drawing.Size(86, 13);
			this.lblDay.TabIndex = 4;
			this.lblDay.Text = "Enter rental days";
			// 
			// lblTotal
			// 
			this.lblTotal.AutoSize = true;
			this.lblTotal.Location = new System.Drawing.Point(119, 224);
			this.lblTotal.Name = "lblTotal";
			this.lblTotal.Size = new System.Drawing.Size(0, 13);
			this.lblTotal.TabIndex = 5;
			// 
			// btnCalc
			// 
			this.btnCalc.Location = new System.Drawing.Point(92, 176);
			this.btnCalc.Name = "btnCalc";
			this.btnCalc.Size = new System.Drawing.Size(101, 23);
			this.btnCalc.TabIndex = 6;
			this.btnCalc.Text = "Calculate total";
			this.btnCalc.UseVisualStyleBackColor = true;
			// 
			// txtAge
			// 
			this.txtAge.Location = new System.Drawing.Point(102, 31);
			this.txtAge.Name = "txtAge";
			this.txtAge.Size = new System.Drawing.Size(100, 20);
			this.txtAge.TabIndex = 7;
			this.txtAge.TextChanged += new System.EventHandler(this.txtAge_TextChanged);
			// 
			// txtDay
			// 
			this.txtDay.Location = new System.Drawing.Point(102, 59);
			this.txtDay.Name = "txtDay";
			this.txtDay.Size = new System.Drawing.Size(100, 20);
			this.txtDay.TabIndex = 8;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(284, 261);
			this.Controls.Add(this.txtDay);
			this.Controls.Add(this.txtAge);
			this.Controls.Add(this.btnCalc);
			this.Controls.Add(this.lblTotal);
			this.Controls.Add(this.lblDay);
			this.Controls.Add(this.lblAge);
			this.Controls.Add(this.rdBtnLux);
			this.Controls.Add(this.rdBtnMid);
			this.Controls.Add(this.rdBtnComp);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.RadioButton rdBtnComp;
		private System.Windows.Forms.RadioButton rdBtnMid;
		private System.Windows.Forms.RadioButton rdBtnLux;
		private System.Windows.Forms.Label lblAge;
		private System.Windows.Forms.Label lblDay;
		private System.Windows.Forms.Label lblTotal;
		private System.Windows.Forms.Button btnCalc;
		private System.Windows.Forms.TextBox txtAge;
		private System.Windows.Forms.TextBox txtDay;
	}
}


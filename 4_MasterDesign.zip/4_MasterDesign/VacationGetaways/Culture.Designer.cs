﻿namespace VacationGetaways
{
    partial class frmCulture
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCulture = new System.Windows.Forms.Label();
            this.btnSingapore1 = new System.Windows.Forms.Button();
            this.btnJapan1 = new System.Windows.Forms.Button();
            this.btnHawaii1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.rdb2 = new System.Windows.Forms.RadioButton();
            this.rdb1 = new System.Windows.Forms.RadioButton();
            this.lblTravelersQ = new System.Windows.Forms.Label();
            this.btnSingapore2 = new System.Windows.Forms.Button();
            this.btnJapan2 = new System.Windows.Forms.Button();
            this.btnHawaii2 = new System.Windows.Forms.Button();
            this.lblHawaii = new System.Windows.Forms.Label();
            this.lblJapan = new System.Windows.Forms.Label();
            this.lblSingapore = new System.Windows.Forms.Label();
            this.lblError1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCulture
            // 
            this.lblCulture.AutoSize = true;
            this.lblCulture.Location = new System.Drawing.Point(274, 35);
            this.lblCulture.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCulture.Name = "lblCulture";
            this.lblCulture.Size = new System.Drawing.Size(58, 13);
            this.lblCulture.TabIndex = 7;
            this.lblCulture.Text = "CULTURE";
            // 
            // btnSingapore1
            // 
            this.btnSingapore1.BackgroundImage = global::VacationGetaways.Properties.Resources.singapore;
            this.btnSingapore1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSingapore1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.btnSingapore1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSingapore1.Location = new System.Drawing.Point(7, 357);
            this.btnSingapore1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSingapore1.Name = "btnSingapore1";
            this.btnSingapore1.Size = new System.Drawing.Size(130, 91);
            this.btnSingapore1.TabIndex = 15;
            this.btnSingapore1.Text = "Singapore";
            this.btnSingapore1.UseVisualStyleBackColor = true;
            // 
            // btnJapan1
            // 
            this.btnJapan1.BackgroundImage = global::VacationGetaways.Properties.Resources.sakura_tg;
            this.btnJapan1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnJapan1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.btnJapan1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnJapan1.Location = new System.Drawing.Point(7, 234);
            this.btnJapan1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnJapan1.Name = "btnJapan1";
            this.btnJapan1.Size = new System.Drawing.Size(130, 91);
            this.btnJapan1.TabIndex = 14;
            this.btnJapan1.Text = "Japanese Cherry Blossom Fesitval";
            this.btnJapan1.UseVisualStyleBackColor = true;
            // 
            // btnHawaii1
            // 
            this.btnHawaii1.BackgroundImage = global::VacationGetaways.Properties.Resources.large_image20150930_9589_1979t5n;
            this.btnHawaii1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnHawaii1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.btnHawaii1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnHawaii1.Location = new System.Drawing.Point(7, 121);
            this.btnHawaii1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnHawaii1.Name = "btnHawaii1";
            this.btnHawaii1.Size = new System.Drawing.Size(130, 91);
            this.btnHawaii1.TabIndex = 3;
            this.btnHawaii1.Text = "Hawaiian Luau";
            this.btnHawaii1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::VacationGetaways.Properties.Resources.Globe;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(9, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 102);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // rdb2
            // 
            this.rdb2.AutoSize = true;
            this.rdb2.Location = new System.Drawing.Point(354, 63);
            this.rdb2.Name = "rdb2";
            this.rdb2.Size = new System.Drawing.Size(31, 17);
            this.rdb2.TabIndex = 49;
            this.rdb2.TabStop = true;
            this.rdb2.Text = "2";
            this.rdb2.UseVisualStyleBackColor = true;
            // 
            // rdb1
            // 
            this.rdb1.AutoSize = true;
            this.rdb1.Location = new System.Drawing.Point(317, 63);
            this.rdb1.Name = "rdb1";
            this.rdb1.Size = new System.Drawing.Size(31, 17);
            this.rdb1.TabIndex = 48;
            this.rdb1.TabStop = true;
            this.rdb1.Text = "1";
            this.rdb1.UseVisualStyleBackColor = true;
            // 
            // lblTravelersQ
            // 
            this.lblTravelersQ.AutoSize = true;
            this.lblTravelersQ.Location = new System.Drawing.Point(205, 66);
            this.lblTravelersQ.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTravelersQ.Name = "lblTravelersQ";
            this.lblTravelersQ.Size = new System.Drawing.Size(110, 13);
            this.lblTravelersQ.TabIndex = 47;
            this.lblTravelersQ.Text = "How many Travelers?";
            // 
            // btnSingapore2
            // 
            this.btnSingapore2.Location = new System.Drawing.Point(387, 391);
            this.btnSingapore2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSingapore2.Name = "btnSingapore2";
            this.btnSingapore2.Size = new System.Drawing.Size(68, 19);
            this.btnSingapore2.TabIndex = 52;
            this.btnSingapore2.Text = "Select";
            this.btnSingapore2.UseVisualStyleBackColor = true;
            // 
            // btnJapan2
            // 
            this.btnJapan2.Location = new System.Drawing.Point(387, 265);
            this.btnJapan2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnJapan2.Name = "btnJapan2";
            this.btnJapan2.Size = new System.Drawing.Size(68, 19);
            this.btnJapan2.TabIndex = 51;
            this.btnJapan2.Text = "Select";
            this.btnJapan2.UseVisualStyleBackColor = true;
            // 
            // btnHawaii2
            // 
            this.btnHawaii2.Location = new System.Drawing.Point(387, 138);
            this.btnHawaii2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnHawaii2.Name = "btnHawaii2";
            this.btnHawaii2.Size = new System.Drawing.Size(68, 19);
            this.btnHawaii2.TabIndex = 50;
            this.btnHawaii2.Text = "Select ";
            this.btnHawaii2.UseVisualStyleBackColor = true;
            // 
            // lblHawaii
            // 
            this.lblHawaii.AutoSize = true;
            this.lblHawaii.Location = new System.Drawing.Point(139, 121);
            this.lblHawaii.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHawaii.Name = "lblHawaii";
            this.lblHawaii.Size = new System.Drawing.Size(191, 13);
            this.lblHawaii.TabIndex = 53;
            this.lblHawaii.Text = "*Display 1P or 2P description with price";
            // 
            // lblJapan
            // 
            this.lblJapan.AutoSize = true;
            this.lblJapan.Location = new System.Drawing.Point(141, 243);
            this.lblJapan.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblJapan.Name = "lblJapan";
            this.lblJapan.Size = new System.Drawing.Size(191, 13);
            this.lblJapan.TabIndex = 54;
            this.lblJapan.Text = "*Display 1P or 2P description with price";
            // 
            // lblSingapore
            // 
            this.lblSingapore.AutoSize = true;
            this.lblSingapore.Location = new System.Drawing.Point(141, 366);
            this.lblSingapore.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSingapore.Name = "lblSingapore";
            this.lblSingapore.Size = new System.Drawing.Size(191, 13);
            this.lblSingapore.TabIndex = 55;
            this.lblSingapore.Text = "*Display 1P or 2P description with price";
            // 
            // lblError1
            // 
            this.lblError1.AutoSize = true;
            this.lblError1.ForeColor = System.Drawing.Color.Red;
            this.lblError1.Location = new System.Drawing.Point(173, 83);
            this.lblError1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblError1.Name = "lblError1";
            this.lblError1.Size = new System.Drawing.Size(241, 13);
            this.lblError1.TabIndex = 60;
            this.lblError1.Text = "Must select number of travellers before continuing";
            // 
            // frmCulture
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(470, 446);
            this.Controls.Add(this.lblError1);
            this.Controls.Add(this.lblSingapore);
            this.Controls.Add(this.lblJapan);
            this.Controls.Add(this.lblHawaii);
            this.Controls.Add(this.btnSingapore2);
            this.Controls.Add(this.btnJapan2);
            this.Controls.Add(this.btnHawaii2);
            this.Controls.Add(this.rdb2);
            this.Controls.Add(this.rdb1);
            this.Controls.Add(this.lblTravelersQ);
            this.Controls.Add(this.btnSingapore1);
            this.Controls.Add(this.btnJapan1);
            this.Controls.Add(this.lblCulture);
            this.Controls.Add(this.btnHawaii1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmCulture";
            this.Text = "Experience Culture";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblCulture;
        private System.Windows.Forms.Button btnHawaii1;
        private System.Windows.Forms.Button btnJapan1;
        private System.Windows.Forms.Button btnSingapore1;
        private System.Windows.Forms.RadioButton rdb2;
        private System.Windows.Forms.RadioButton rdb1;
        private System.Windows.Forms.Label lblTravelersQ;
        private System.Windows.Forms.Button btnSingapore2;
        private System.Windows.Forms.Button btnJapan2;
        private System.Windows.Forms.Button btnHawaii2;
        private System.Windows.Forms.Label lblHawaii;
        private System.Windows.Forms.Label lblJapan;
        private System.Windows.Forms.Label lblSingapore;
        private System.Windows.Forms.Label lblError1;
    }
}
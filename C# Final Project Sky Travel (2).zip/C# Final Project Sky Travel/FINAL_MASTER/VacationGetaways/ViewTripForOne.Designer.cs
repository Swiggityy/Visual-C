﻿namespace VacationGetaways
{
    partial class ViewTripForOne
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewTripForOne));
            this.lblDateOfTravel2 = new System.Windows.Forms.Label();
            this.lblDateOfTravel = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lblResults = new System.Windows.Forms.Label();
            this.lblNondisclosure = new System.Windows.Forms.Label();
            this.lblMiddleName = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblBirthDate = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblContactNumber = new System.Windows.Forms.Label();
            this.lblLoggedInUserEmail = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblCardHolderName = new System.Windows.Forms.Label();
            this.lblDebitCreditCardNumber = new System.Windows.Forms.Label();
            this.lblExpireMonth = new System.Windows.Forms.Label();
            this.lblExpireYear = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblCreditCardType = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblDateOfTravel2
            // 
            this.lblDateOfTravel2.AutoSize = true;
            this.lblDateOfTravel2.BackColor = System.Drawing.Color.Transparent;
            this.lblDateOfTravel2.ForeColor = System.Drawing.Color.DimGray;
            this.lblDateOfTravel2.Location = new System.Drawing.Point(140, 30);
            this.lblDateOfTravel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDateOfTravel2.Name = "lblDateOfTravel2";
            this.lblDateOfTravel2.Size = new System.Drawing.Size(0, 17);
            this.lblDateOfTravel2.TabIndex = 219;
            // 
            // lblDateOfTravel
            // 
            this.lblDateOfTravel.AutoSize = true;
            this.lblDateOfTravel.BackColor = System.Drawing.Color.Transparent;
            this.lblDateOfTravel.ForeColor = System.Drawing.Color.DimGray;
            this.lblDateOfTravel.Location = new System.Drawing.Point(20, 30);
            this.lblDateOfTravel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDateOfTravel.Name = "lblDateOfTravel";
            this.lblDateOfTravel.Size = new System.Drawing.Size(109, 17);
            this.lblDateOfTravel.TabIndex = 218;
            this.lblDateOfTravel.Text = "Date of Booking";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.ForeColor = System.Drawing.Color.DimGray;
            this.label17.Location = new System.Drawing.Point(50, 108);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 17);
            this.label17.TabIndex = 210;
            this.label17.Text = "Middle Name";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.ForeColor = System.Drawing.Color.DimGray;
            this.label18.Location = new System.Drawing.Point(84, 193);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(56, 17);
            this.label18.TabIndex = 209;
            this.label18.Text = "Gender";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.ForeColor = System.Drawing.Color.DimGray;
            this.label19.Location = new System.Drawing.Point(52, 170);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(87, 17);
            this.label19.TabIndex = 208;
            this.label19.Text = "Date of Birth";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.ForeColor = System.Drawing.Color.DimGray;
            this.label20.Location = new System.Drawing.Point(63, 92);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(76, 17);
            this.label20.TabIndex = 207;
            this.label20.Text = "First Name";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.ForeColor = System.Drawing.Color.DimGray;
            this.label21.Location = new System.Drawing.Point(63, 124);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(76, 17);
            this.label21.TabIndex = 206;
            this.label21.Text = "Last Name";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.ForeColor = System.Drawing.Color.DimGray;
            this.label22.Location = new System.Drawing.Point(28, 150);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(110, 17);
            this.label22.TabIndex = 205;
            this.label22.Text = "Contact Number";
            // 
            // lblResults
            // 
            this.lblResults.BackColor = System.Drawing.Color.Transparent;
            this.lblResults.ForeColor = System.Drawing.Color.Black;
            this.lblResults.Location = new System.Drawing.Point(411, 74);
            this.lblResults.MaximumSize = new System.Drawing.Size(195, 131);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(195, 126);
            this.lblResults.TabIndex = 203;
            // 
            // lblNondisclosure
            // 
            this.lblNondisclosure.AutoSize = true;
            this.lblNondisclosure.BackColor = System.Drawing.Color.Transparent;
            this.lblNondisclosure.ForeColor = System.Drawing.Color.DimGray;
            this.lblNondisclosure.Location = new System.Drawing.Point(23, 338);
            this.lblNondisclosure.Name = "lblNondisclosure";
            this.lblNondisclosure.Size = new System.Drawing.Size(0, 17);
            this.lblNondisclosure.TabIndex = 202;
            // 
            // lblMiddleName
            // 
            this.lblMiddleName.AutoSize = true;
            this.lblMiddleName.BackColor = System.Drawing.Color.Transparent;
            this.lblMiddleName.ForeColor = System.Drawing.Color.DimGray;
            this.lblMiddleName.Location = new System.Drawing.Point(171, 108);
            this.lblMiddleName.Name = "lblMiddleName";
            this.lblMiddleName.Size = new System.Drawing.Size(0, 17);
            this.lblMiddleName.TabIndex = 196;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(55, 338);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 17);
            this.label8.TabIndex = 195;
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.BackColor = System.Drawing.Color.Transparent;
            this.lblGender.ForeColor = System.Drawing.Color.DimGray;
            this.lblGender.Location = new System.Drawing.Point(171, 193);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(0, 17);
            this.lblGender.TabIndex = 194;
            // 
            // lblBirthDate
            // 
            this.lblBirthDate.AutoSize = true;
            this.lblBirthDate.BackColor = System.Drawing.Color.Transparent;
            this.lblBirthDate.ForeColor = System.Drawing.Color.DimGray;
            this.lblBirthDate.Location = new System.Drawing.Point(171, 170);
            this.lblBirthDate.Name = "lblBirthDate";
            this.lblBirthDate.Size = new System.Drawing.Size(0, 17);
            this.lblBirthDate.TabIndex = 193;
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstName.ForeColor = System.Drawing.Color.DimGray;
            this.lblFirstName.Location = new System.Drawing.Point(171, 92);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(0, 17);
            this.lblFirstName.TabIndex = 192;
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.BackColor = System.Drawing.Color.Transparent;
            this.lblLastName.ForeColor = System.Drawing.Color.DimGray;
            this.lblLastName.Location = new System.Drawing.Point(171, 124);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(0, 17);
            this.lblLastName.TabIndex = 190;
            // 
            // lblContactNumber
            // 
            this.lblContactNumber.AutoSize = true;
            this.lblContactNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblContactNumber.ForeColor = System.Drawing.Color.DimGray;
            this.lblContactNumber.Location = new System.Drawing.Point(171, 150);
            this.lblContactNumber.Name = "lblContactNumber";
            this.lblContactNumber.Size = new System.Drawing.Size(0, 17);
            this.lblContactNumber.TabIndex = 188;
            // 
            // lblLoggedInUserEmail
            // 
            this.lblLoggedInUserEmail.AutoSize = true;
            this.lblLoggedInUserEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblLoggedInUserEmail.ForeColor = System.Drawing.Color.DimGray;
            this.lblLoggedInUserEmail.Location = new System.Drawing.Point(28, 14);
            this.lblLoggedInUserEmail.Name = "lblLoggedInUserEmail";
            this.lblLoggedInUserEmail.Size = new System.Drawing.Size(0, 17);
            this.lblLoggedInUserEmail.TabIndex = 217;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Segoe Script", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(191, 325);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(333, 44);
            this.label13.TabIndex = 221;
            this.label13.Text = "Payment Information";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe Script", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(257, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 44);
            this.label1.TabIndex = 222;
            this.label1.Text = "Trip Details";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightCyan;
            this.panel1.Controls.Add(this.lblDateOfTravel2);
            this.panel1.Controls.Add(this.lblDateOfTravel);
            this.panel1.Controls.Add(this.lblLoggedInUserEmail);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.lblResults);
            this.panel1.Controls.Add(this.lblMiddleName);
            this.panel1.Controls.Add(this.lblGender);
            this.panel1.Controls.Add(this.lblBirthDate);
            this.panel1.Controls.Add(this.lblFirstName);
            this.panel1.Controls.Add(this.lblLastName);
            this.panel1.Controls.Add(this.lblContactNumber);
            this.panel1.Location = new System.Drawing.Point(35, 56);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(630, 248);
            this.panel1.TabIndex = 223;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.ForeColor = System.Drawing.Color.DimGray;
            this.label12.Location = new System.Drawing.Point(112, 82);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 17);
            this.label12.TabIndex = 197;
            this.label12.Text = "Security Code";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(90, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 17);
            this.label9.TabIndex = 198;
            this.label9.Text = "Cardholder Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(41, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 17);
            this.label6.TabIndex = 199;
            this.label6.Text = "Debit/Credit card Number";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.ForeColor = System.Drawing.Color.DimGray;
            this.label14.Location = new System.Drawing.Point(103, 63);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(104, 17);
            this.label14.TabIndex = 201;
            this.label14.Text = "Expiration Date";
            // 
            // lblCardHolderName
            // 
            this.lblCardHolderName.AutoSize = true;
            this.lblCardHolderName.BackColor = System.Drawing.Color.Transparent;
            this.lblCardHolderName.ForeColor = System.Drawing.Color.DimGray;
            this.lblCardHolderName.Location = new System.Drawing.Point(231, 24);
            this.lblCardHolderName.Name = "lblCardHolderName";
            this.lblCardHolderName.Size = new System.Drawing.Size(0, 17);
            this.lblCardHolderName.TabIndex = 211;
            // 
            // lblDebitCreditCardNumber
            // 
            this.lblDebitCreditCardNumber.AutoSize = true;
            this.lblDebitCreditCardNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblDebitCreditCardNumber.ForeColor = System.Drawing.Color.DimGray;
            this.lblDebitCreditCardNumber.Location = new System.Drawing.Point(231, 45);
            this.lblDebitCreditCardNumber.Name = "lblDebitCreditCardNumber";
            this.lblDebitCreditCardNumber.Size = new System.Drawing.Size(0, 17);
            this.lblDebitCreditCardNumber.TabIndex = 212;
            // 
            // lblExpireMonth
            // 
            this.lblExpireMonth.AutoSize = true;
            this.lblExpireMonth.BackColor = System.Drawing.Color.Transparent;
            this.lblExpireMonth.ForeColor = System.Drawing.Color.DimGray;
            this.lblExpireMonth.Location = new System.Drawing.Point(231, 64);
            this.lblExpireMonth.Name = "lblExpireMonth";
            this.lblExpireMonth.Size = new System.Drawing.Size(0, 17);
            this.lblExpireMonth.TabIndex = 213;
            // 
            // lblExpireYear
            // 
            this.lblExpireYear.AutoSize = true;
            this.lblExpireYear.BackColor = System.Drawing.Color.Transparent;
            this.lblExpireYear.ForeColor = System.Drawing.Color.DimGray;
            this.lblExpireYear.Location = new System.Drawing.Point(231, 83);
            this.lblExpireYear.Name = "lblExpireYear";
            this.lblExpireYear.Size = new System.Drawing.Size(0, 17);
            this.lblExpireYear.TabIndex = 214;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(95, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 17);
            this.label3.TabIndex = 215;
            this.label3.Text = "Credit Card Type";
            // 
            // lblCreditCardType
            // 
            this.lblCreditCardType.AutoSize = true;
            this.lblCreditCardType.BackColor = System.Drawing.Color.Transparent;
            this.lblCreditCardType.ForeColor = System.Drawing.Color.DimGray;
            this.lblCreditCardType.Location = new System.Drawing.Point(231, 105);
            this.lblCreditCardType.Name = "lblCreditCardType";
            this.lblCreditCardType.Size = new System.Drawing.Size(0, 17);
            this.lblCreditCardType.TabIndex = 216;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightCyan;
            this.panel2.Controls.Add(this.lblCreditCardType);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.lblExpireYear);
            this.panel2.Controls.Add(this.lblExpireMonth);
            this.panel2.Controls.Add(this.lblDebitCreditCardNumber);
            this.panel2.Controls.Add(this.lblCardHolderName);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Enabled = false;
            this.panel2.Location = new System.Drawing.Point(35, 407);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(628, 143);
            this.panel2.TabIndex = 224;
            // 
            // ViewTripForOne
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(725, 721);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lblNondisclosure);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximumSize = new System.Drawing.Size(743, 768);
            this.MinimumSize = new System.Drawing.Size(743, 768);
            this.Name = "ViewTripForOne";
            this.Text = "ViewTripForOne";
            this.Load += new System.EventHandler(this.ViewTripForOne_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDateOfTravel2;
        private System.Windows.Forms.Label lblDateOfTravel;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.Label lblNondisclosure;
        private System.Windows.Forms.Label lblMiddleName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblBirthDate;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblContactNumber;
        private System.Windows.Forms.Label lblLoggedInUserEmail;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblCardHolderName;
        private System.Windows.Forms.Label lblDebitCreditCardNumber;
        private System.Windows.Forms.Label lblExpireMonth;
        private System.Windows.Forms.Label lblExpireYear;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCreditCardType;
        private System.Windows.Forms.Panel panel2;
    }
}
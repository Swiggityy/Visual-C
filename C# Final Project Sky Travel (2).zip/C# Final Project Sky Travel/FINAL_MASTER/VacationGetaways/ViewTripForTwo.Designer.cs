﻿namespace VacationGetaways
{
    partial class ViewTripForTwo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewTripForTwo));
            this.lblMidName2Lbl = new System.Windows.Forms.Label();
            this.lblGender2Lbl = new System.Windows.Forms.Label();
            this.lblDateBirth2Lbl = new System.Windows.Forms.Label();
            this.lblFirstName2Lbl = new System.Windows.Forms.Label();
            this.lblLastName2Lbl = new System.Windows.Forms.Label();
            this.lblContact2Lbl = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblMidName2Data = new System.Windows.Forms.Label();
            this.lblGender2Data = new System.Windows.Forms.Label();
            this.lblDateBirth2Data = new System.Windows.Forms.Label();
            this.lblFirstName2Data = new System.Windows.Forms.Label();
            this.lblLastName2Data = new System.Windows.Forms.Label();
            this.lblContact2Data = new System.Windows.Forms.Label();
            this.lblDateOfTravel2 = new System.Windows.Forms.Label();
            this.lblDateOfTravel = new System.Windows.Forms.Label();
            this.lblLoggedInUserEmail = new System.Windows.Forms.Label();
            this.lblCreditCardType = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblExpireYear = new System.Windows.Forms.Label();
            this.lblExpireMonth = new System.Windows.Forms.Label();
            this.lblDebitCreditCardNumber = new System.Windows.Forms.Label();
            this.lblCardHolderName = new System.Windows.Forms.Label();
            this.lblMidName1Lbl = new System.Windows.Forms.Label();
            this.lblGender1Lbl = new System.Windows.Forms.Label();
            this.lblDateBirth1Lbl = new System.Windows.Forms.Label();
            this.lblFirstName1Lbl = new System.Windows.Forms.Label();
            this.lblLastName1Lbl = new System.Windows.Forms.Label();
            this.lblContact1Lbl = new System.Windows.Forms.Label();
            this.lblResults = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblMidName1Data = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblGender1Data = new System.Windows.Forms.Label();
            this.lblDateBirth1Data = new System.Windows.Forms.Label();
            this.lblFirstName1Data = new System.Windows.Forms.Label();
            this.lblLastName1Data = new System.Windows.Forms.Label();
            this.lblContact1Data = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCelebration = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblSecurityCode = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblMidName2Lbl
            // 
            this.lblMidName2Lbl.AutoSize = true;
            this.lblMidName2Lbl.BackColor = System.Drawing.Color.Transparent;
            this.lblMidName2Lbl.ForeColor = System.Drawing.Color.DimGray;
            this.lblMidName2Lbl.Location = new System.Drawing.Point(51, 32);
            this.lblMidName2Lbl.Name = "lblMidName2Lbl";
            this.lblMidName2Lbl.Size = new System.Drawing.Size(90, 17);
            this.lblMidName2Lbl.TabIndex = 323;
            this.lblMidName2Lbl.Text = "Middle Name";
            // 
            // lblGender2Lbl
            // 
            this.lblGender2Lbl.AutoSize = true;
            this.lblGender2Lbl.BackColor = System.Drawing.Color.Transparent;
            this.lblGender2Lbl.ForeColor = System.Drawing.Color.DimGray;
            this.lblGender2Lbl.Location = new System.Drawing.Point(84, 106);
            this.lblGender2Lbl.Name = "lblGender2Lbl";
            this.lblGender2Lbl.Size = new System.Drawing.Size(56, 17);
            this.lblGender2Lbl.TabIndex = 322;
            this.lblGender2Lbl.Text = "Gender";
            // 
            // lblDateBirth2Lbl
            // 
            this.lblDateBirth2Lbl.AutoSize = true;
            this.lblDateBirth2Lbl.BackColor = System.Drawing.Color.Transparent;
            this.lblDateBirth2Lbl.ForeColor = System.Drawing.Color.DimGray;
            this.lblDateBirth2Lbl.Location = new System.Drawing.Point(52, 90);
            this.lblDateBirth2Lbl.Name = "lblDateBirth2Lbl";
            this.lblDateBirth2Lbl.Size = new System.Drawing.Size(87, 17);
            this.lblDateBirth2Lbl.TabIndex = 321;
            this.lblDateBirth2Lbl.Text = "Date of Birth";
            // 
            // lblFirstName2Lbl
            // 
            this.lblFirstName2Lbl.AutoSize = true;
            this.lblFirstName2Lbl.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstName2Lbl.ForeColor = System.Drawing.Color.DimGray;
            this.lblFirstName2Lbl.Location = new System.Drawing.Point(63, 14);
            this.lblFirstName2Lbl.Name = "lblFirstName2Lbl";
            this.lblFirstName2Lbl.Size = new System.Drawing.Size(76, 17);
            this.lblFirstName2Lbl.TabIndex = 320;
            this.lblFirstName2Lbl.Text = "First Name";
            // 
            // lblLastName2Lbl
            // 
            this.lblLastName2Lbl.AutoSize = true;
            this.lblLastName2Lbl.BackColor = System.Drawing.Color.Transparent;
            this.lblLastName2Lbl.ForeColor = System.Drawing.Color.DimGray;
            this.lblLastName2Lbl.Location = new System.Drawing.Point(63, 50);
            this.lblLastName2Lbl.Name = "lblLastName2Lbl";
            this.lblLastName2Lbl.Size = new System.Drawing.Size(76, 17);
            this.lblLastName2Lbl.TabIndex = 319;
            this.lblLastName2Lbl.Text = "Last Name";
            // 
            // lblContact2Lbl
            // 
            this.lblContact2Lbl.AutoSize = true;
            this.lblContact2Lbl.BackColor = System.Drawing.Color.Transparent;
            this.lblContact2Lbl.ForeColor = System.Drawing.Color.DimGray;
            this.lblContact2Lbl.Location = new System.Drawing.Point(29, 74);
            this.lblContact2Lbl.Name = "lblContact2Lbl";
            this.lblContact2Lbl.Size = new System.Drawing.Size(110, 17);
            this.lblContact2Lbl.TabIndex = 318;
            this.lblContact2Lbl.Text = "Contact Number";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.ForeColor = System.Drawing.Color.DimGray;
            this.label11.Location = new System.Drawing.Point(278, 82);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 17);
            this.label11.TabIndex = 317;
            // 
            // lblMidName2Data
            // 
            this.lblMidName2Data.AutoSize = true;
            this.lblMidName2Data.BackColor = System.Drawing.Color.Transparent;
            this.lblMidName2Data.ForeColor = System.Drawing.Color.DimGray;
            this.lblMidName2Data.Location = new System.Drawing.Point(167, 32);
            this.lblMidName2Data.Name = "lblMidName2Data";
            this.lblMidName2Data.Size = new System.Drawing.Size(0, 17);
            this.lblMidName2Data.TabIndex = 316;
            // 
            // lblGender2Data
            // 
            this.lblGender2Data.AutoSize = true;
            this.lblGender2Data.BackColor = System.Drawing.Color.Transparent;
            this.lblGender2Data.ForeColor = System.Drawing.Color.DimGray;
            this.lblGender2Data.Location = new System.Drawing.Point(167, 106);
            this.lblGender2Data.Name = "lblGender2Data";
            this.lblGender2Data.Size = new System.Drawing.Size(0, 17);
            this.lblGender2Data.TabIndex = 315;
            // 
            // lblDateBirth2Data
            // 
            this.lblDateBirth2Data.AutoSize = true;
            this.lblDateBirth2Data.BackColor = System.Drawing.Color.Transparent;
            this.lblDateBirth2Data.ForeColor = System.Drawing.Color.DimGray;
            this.lblDateBirth2Data.Location = new System.Drawing.Point(167, 90);
            this.lblDateBirth2Data.Name = "lblDateBirth2Data";
            this.lblDateBirth2Data.Size = new System.Drawing.Size(0, 17);
            this.lblDateBirth2Data.TabIndex = 314;
            // 
            // lblFirstName2Data
            // 
            this.lblFirstName2Data.AutoSize = true;
            this.lblFirstName2Data.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstName2Data.ForeColor = System.Drawing.Color.DimGray;
            this.lblFirstName2Data.Location = new System.Drawing.Point(166, 14);
            this.lblFirstName2Data.Name = "lblFirstName2Data";
            this.lblFirstName2Data.Size = new System.Drawing.Size(0, 17);
            this.lblFirstName2Data.TabIndex = 313;
            // 
            // lblLastName2Data
            // 
            this.lblLastName2Data.AutoSize = true;
            this.lblLastName2Data.BackColor = System.Drawing.Color.Transparent;
            this.lblLastName2Data.ForeColor = System.Drawing.Color.DimGray;
            this.lblLastName2Data.Location = new System.Drawing.Point(166, 50);
            this.lblLastName2Data.Name = "lblLastName2Data";
            this.lblLastName2Data.Size = new System.Drawing.Size(0, 17);
            this.lblLastName2Data.TabIndex = 312;
            // 
            // lblContact2Data
            // 
            this.lblContact2Data.AutoSize = true;
            this.lblContact2Data.BackColor = System.Drawing.Color.Transparent;
            this.lblContact2Data.ForeColor = System.Drawing.Color.DimGray;
            this.lblContact2Data.Location = new System.Drawing.Point(167, 74);
            this.lblContact2Data.Name = "lblContact2Data";
            this.lblContact2Data.Size = new System.Drawing.Size(0, 17);
            this.lblContact2Data.TabIndex = 311;
            // 
            // lblDateOfTravel2
            // 
            this.lblDateOfTravel2.AutoSize = true;
            this.lblDateOfTravel2.BackColor = System.Drawing.Color.Transparent;
            this.lblDateOfTravel2.ForeColor = System.Drawing.Color.DimGray;
            this.lblDateOfTravel2.Location = new System.Drawing.Point(124, 12);
            this.lblDateOfTravel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDateOfTravel2.Name = "lblDateOfTravel2";
            this.lblDateOfTravel2.Size = new System.Drawing.Size(0, 17);
            this.lblDateOfTravel2.TabIndex = 308;
            // 
            // lblDateOfTravel
            // 
            this.lblDateOfTravel.AutoSize = true;
            this.lblDateOfTravel.BackColor = System.Drawing.Color.Transparent;
            this.lblDateOfTravel.ForeColor = System.Drawing.Color.DimGray;
            this.lblDateOfTravel.Location = new System.Drawing.Point(4, 12);
            this.lblDateOfTravel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDateOfTravel.Name = "lblDateOfTravel";
            this.lblDateOfTravel.Size = new System.Drawing.Size(109, 17);
            this.lblDateOfTravel.TabIndex = 307;
            this.lblDateOfTravel.Text = "Date of Booking";
            // 
            // lblLoggedInUserEmail
            // 
            this.lblLoggedInUserEmail.AutoSize = true;
            this.lblLoggedInUserEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblLoggedInUserEmail.ForeColor = System.Drawing.Color.DimGray;
            this.lblLoggedInUserEmail.Location = new System.Drawing.Point(48, 38);
            this.lblLoggedInUserEmail.Name = "lblLoggedInUserEmail";
            this.lblLoggedInUserEmail.Size = new System.Drawing.Size(0, 17);
            this.lblLoggedInUserEmail.TabIndex = 306;
            // 
            // lblCreditCardType
            // 
            this.lblCreditCardType.AutoSize = true;
            this.lblCreditCardType.BackColor = System.Drawing.Color.Transparent;
            this.lblCreditCardType.ForeColor = System.Drawing.Color.DimGray;
            this.lblCreditCardType.Location = new System.Drawing.Point(205, 124);
            this.lblCreditCardType.Name = "lblCreditCardType";
            this.lblCreditCardType.Size = new System.Drawing.Size(0, 17);
            this.lblCreditCardType.TabIndex = 305;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(106, 600);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 17);
            this.label3.TabIndex = 304;
            this.label3.Text = "Credit Card Type";
            // 
            // lblExpireYear
            // 
            this.lblExpireYear.AutoSize = true;
            this.lblExpireYear.BackColor = System.Drawing.Color.Transparent;
            this.lblExpireYear.ForeColor = System.Drawing.Color.DimGray;
            this.lblExpireYear.Location = new System.Drawing.Point(205, 99);
            this.lblExpireYear.Name = "lblExpireYear";
            this.lblExpireYear.Size = new System.Drawing.Size(0, 17);
            this.lblExpireYear.TabIndex = 303;
            // 
            // lblExpireMonth
            // 
            this.lblExpireMonth.AutoSize = true;
            this.lblExpireMonth.BackColor = System.Drawing.Color.Transparent;
            this.lblExpireMonth.ForeColor = System.Drawing.Color.DimGray;
            this.lblExpireMonth.Location = new System.Drawing.Point(205, 78);
            this.lblExpireMonth.Name = "lblExpireMonth";
            this.lblExpireMonth.Size = new System.Drawing.Size(0, 17);
            this.lblExpireMonth.TabIndex = 302;
            // 
            // lblDebitCreditCardNumber
            // 
            this.lblDebitCreditCardNumber.AutoSize = true;
            this.lblDebitCreditCardNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblDebitCreditCardNumber.ForeColor = System.Drawing.Color.DimGray;
            this.lblDebitCreditCardNumber.Location = new System.Drawing.Point(205, 55);
            this.lblDebitCreditCardNumber.Name = "lblDebitCreditCardNumber";
            this.lblDebitCreditCardNumber.Size = new System.Drawing.Size(0, 17);
            this.lblDebitCreditCardNumber.TabIndex = 301;
            // 
            // lblCardHolderName
            // 
            this.lblCardHolderName.AutoSize = true;
            this.lblCardHolderName.BackColor = System.Drawing.Color.Transparent;
            this.lblCardHolderName.ForeColor = System.Drawing.Color.DimGray;
            this.lblCardHolderName.Location = new System.Drawing.Point(205, 32);
            this.lblCardHolderName.Name = "lblCardHolderName";
            this.lblCardHolderName.Size = new System.Drawing.Size(0, 17);
            this.lblCardHolderName.TabIndex = 300;
            // 
            // lblMidName1Lbl
            // 
            this.lblMidName1Lbl.AutoSize = true;
            this.lblMidName1Lbl.BackColor = System.Drawing.Color.Transparent;
            this.lblMidName1Lbl.ForeColor = System.Drawing.Color.DimGray;
            this.lblMidName1Lbl.Location = new System.Drawing.Point(52, 66);
            this.lblMidName1Lbl.Name = "lblMidName1Lbl";
            this.lblMidName1Lbl.Size = new System.Drawing.Size(90, 17);
            this.lblMidName1Lbl.TabIndex = 299;
            this.lblMidName1Lbl.Text = "Middle Name";
            // 
            // lblGender1Lbl
            // 
            this.lblGender1Lbl.AutoSize = true;
            this.lblGender1Lbl.BackColor = System.Drawing.Color.Transparent;
            this.lblGender1Lbl.ForeColor = System.Drawing.Color.DimGray;
            this.lblGender1Lbl.Location = new System.Drawing.Point(52, 134);
            this.lblGender1Lbl.Name = "lblGender1Lbl";
            this.lblGender1Lbl.Size = new System.Drawing.Size(56, 17);
            this.lblGender1Lbl.TabIndex = 298;
            this.lblGender1Lbl.Text = "Gender";
            // 
            // lblDateBirth1Lbl
            // 
            this.lblDateBirth1Lbl.AutoSize = true;
            this.lblDateBirth1Lbl.BackColor = System.Drawing.Color.Transparent;
            this.lblDateBirth1Lbl.ForeColor = System.Drawing.Color.DimGray;
            this.lblDateBirth1Lbl.Location = new System.Drawing.Point(52, 117);
            this.lblDateBirth1Lbl.Name = "lblDateBirth1Lbl";
            this.lblDateBirth1Lbl.Size = new System.Drawing.Size(87, 17);
            this.lblDateBirth1Lbl.TabIndex = 297;
            this.lblDateBirth1Lbl.Text = "Date of Birth";
            // 
            // lblFirstName1Lbl
            // 
            this.lblFirstName1Lbl.AutoSize = true;
            this.lblFirstName1Lbl.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstName1Lbl.ForeColor = System.Drawing.Color.DimGray;
            this.lblFirstName1Lbl.Location = new System.Drawing.Point(52, 49);
            this.lblFirstName1Lbl.Name = "lblFirstName1Lbl";
            this.lblFirstName1Lbl.Size = new System.Drawing.Size(76, 17);
            this.lblFirstName1Lbl.TabIndex = 296;
            this.lblFirstName1Lbl.Text = "First Name";
            // 
            // lblLastName1Lbl
            // 
            this.lblLastName1Lbl.AutoSize = true;
            this.lblLastName1Lbl.BackColor = System.Drawing.Color.Transparent;
            this.lblLastName1Lbl.ForeColor = System.Drawing.Color.DimGray;
            this.lblLastName1Lbl.Location = new System.Drawing.Point(52, 83);
            this.lblLastName1Lbl.Name = "lblLastName1Lbl";
            this.lblLastName1Lbl.Size = new System.Drawing.Size(76, 17);
            this.lblLastName1Lbl.TabIndex = 295;
            this.lblLastName1Lbl.Text = "Last Name";
            // 
            // lblContact1Lbl
            // 
            this.lblContact1Lbl.AutoSize = true;
            this.lblContact1Lbl.BackColor = System.Drawing.Color.Transparent;
            this.lblContact1Lbl.ForeColor = System.Drawing.Color.DimGray;
            this.lblContact1Lbl.Location = new System.Drawing.Point(52, 100);
            this.lblContact1Lbl.Name = "lblContact1Lbl";
            this.lblContact1Lbl.Size = new System.Drawing.Size(110, 17);
            this.lblContact1Lbl.TabIndex = 294;
            this.lblContact1Lbl.Text = "Contact Number";
            // 
            // lblResults
            // 
            this.lblResults.BackColor = System.Drawing.Color.Transparent;
            this.lblResults.ForeColor = System.Drawing.Color.DimGray;
            this.lblResults.Location = new System.Drawing.Point(324, 66);
            this.lblResults.MaximumSize = new System.Drawing.Size(195, 131);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(195, 114);
            this.lblResults.TabIndex = 293;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.ForeColor = System.Drawing.Color.DimGray;
            this.label14.Location = new System.Drawing.Point(83, 77);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(104, 17);
            this.label14.TabIndex = 292;
            this.label14.Text = "Expiration Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(22, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 17);
            this.label6.TabIndex = 290;
            this.label6.Text = "Debit/Credit card Number";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(71, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 17);
            this.label9.TabIndex = 289;
            this.label9.Text = "Cardholder Name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.ForeColor = System.Drawing.Color.DimGray;
            this.label12.Location = new System.Drawing.Point(93, 99);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 17);
            this.label12.TabIndex = 288;
            this.label12.Text = "Security Code";
            // 
            // lblMidName1Data
            // 
            this.lblMidName1Data.AutoSize = true;
            this.lblMidName1Data.BackColor = System.Drawing.Color.Transparent;
            this.lblMidName1Data.ForeColor = System.Drawing.Color.DimGray;
            this.lblMidName1Data.Location = new System.Drawing.Point(170, 65);
            this.lblMidName1Data.Name = "lblMidName1Data";
            this.lblMidName1Data.Size = new System.Drawing.Size(0, 17);
            this.lblMidName1Data.TabIndex = 287;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(49, 240);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 17);
            this.label8.TabIndex = 286;
            // 
            // lblGender1Data
            // 
            this.lblGender1Data.AutoSize = true;
            this.lblGender1Data.BackColor = System.Drawing.Color.Transparent;
            this.lblGender1Data.ForeColor = System.Drawing.Color.DimGray;
            this.lblGender1Data.Location = new System.Drawing.Point(171, 134);
            this.lblGender1Data.Name = "lblGender1Data";
            this.lblGender1Data.Size = new System.Drawing.Size(0, 17);
            this.lblGender1Data.TabIndex = 285;
            // 
            // lblDateBirth1Data
            // 
            this.lblDateBirth1Data.AutoSize = true;
            this.lblDateBirth1Data.BackColor = System.Drawing.Color.Transparent;
            this.lblDateBirth1Data.ForeColor = System.Drawing.Color.DimGray;
            this.lblDateBirth1Data.Location = new System.Drawing.Point(171, 119);
            this.lblDateBirth1Data.Name = "lblDateBirth1Data";
            this.lblDateBirth1Data.Size = new System.Drawing.Size(0, 17);
            this.lblDateBirth1Data.TabIndex = 284;
            // 
            // lblFirstName1Data
            // 
            this.lblFirstName1Data.AutoSize = true;
            this.lblFirstName1Data.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstName1Data.ForeColor = System.Drawing.Color.DimGray;
            this.lblFirstName1Data.Location = new System.Drawing.Point(167, 49);
            this.lblFirstName1Data.Name = "lblFirstName1Data";
            this.lblFirstName1Data.Size = new System.Drawing.Size(0, 17);
            this.lblFirstName1Data.TabIndex = 283;
            // 
            // lblLastName1Data
            // 
            this.lblLastName1Data.AutoSize = true;
            this.lblLastName1Data.BackColor = System.Drawing.Color.Transparent;
            this.lblLastName1Data.ForeColor = System.Drawing.Color.DimGray;
            this.lblLastName1Data.Location = new System.Drawing.Point(170, 83);
            this.lblLastName1Data.Name = "lblLastName1Data";
            this.lblLastName1Data.Size = new System.Drawing.Size(0, 17);
            this.lblLastName1Data.TabIndex = 282;
            // 
            // lblContact1Data
            // 
            this.lblContact1Data.AutoSize = true;
            this.lblContact1Data.BackColor = System.Drawing.Color.Transparent;
            this.lblContact1Data.ForeColor = System.Drawing.Color.DimGray;
            this.lblContact1Data.Location = new System.Drawing.Point(170, 103);
            this.lblContact1Data.Name = "lblContact1Data";
            this.lblContact1Data.Size = new System.Drawing.Size(0, 17);
            this.lblContact1Data.TabIndex = 281;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe Script", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(335, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 44);
            this.label1.TabIndex = 324;
            this.label1.Text = "Traveler 1 ";
            // 
            // lblCelebration
            // 
            this.lblCelebration.AutoSize = true;
            this.lblCelebration.BackColor = System.Drawing.Color.Transparent;
            this.lblCelebration.Font = new System.Drawing.Font("Segoe Script", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCelebration.ForeColor = System.Drawing.Color.Black;
            this.lblCelebration.Location = new System.Drawing.Point(196, 7);
            this.lblCelebration.Name = "lblCelebration";
            this.lblCelebration.Size = new System.Drawing.Size(193, 44);
            this.lblCelebration.TabIndex = 325;
            this.lblCelebration.Text = "Trip Details";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightCyan;
            this.panel1.Controls.Add(this.lblDateOfTravel2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblDateOfTravel);
            this.panel1.Controls.Add(this.lblMidName1Lbl);
            this.panel1.Controls.Add(this.lblGender1Lbl);
            this.panel1.Controls.Add(this.lblDateBirth1Lbl);
            this.panel1.Controls.Add(this.lblFirstName1Lbl);
            this.panel1.Controls.Add(this.lblLastName1Lbl);
            this.panel1.Controls.Add(this.lblContact1Lbl);
            this.panel1.Controls.Add(this.lblResults);
            this.panel1.Controls.Add(this.lblMidName1Data);
            this.panel1.Controls.Add(this.lblGender1Data);
            this.panel1.Controls.Add(this.lblDateBirth1Data);
            this.panel1.Controls.Add(this.lblFirstName1Data);
            this.panel1.Controls.Add(this.lblLastName1Data);
            this.panel1.Controls.Add(this.lblContact1Data);
            this.panel1.ForeColor = System.Drawing.Color.DimGray;
            this.panel1.Location = new System.Drawing.Point(30, 57);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(540, 189);
            this.panel1.TabIndex = 326;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Segoe Script", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(340, 5);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(184, 44);
            this.label24.TabIndex = 327;
            this.label24.Text = "Traveler 2 ";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightCyan;
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.lblMidName2Lbl);
            this.panel2.Controls.Add(this.lblGender2Lbl);
            this.panel2.Controls.Add(this.lblDateBirth2Lbl);
            this.panel2.Controls.Add(this.lblFirstName2Lbl);
            this.panel2.Controls.Add(this.lblLastName2Lbl);
            this.panel2.Controls.Add(this.lblContact2Lbl);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.lblMidName2Data);
            this.panel2.Controls.Add(this.lblGender2Data);
            this.panel2.Controls.Add(this.lblDateBirth2Data);
            this.panel2.Controls.Add(this.lblFirstName2Data);
            this.panel2.Controls.Add(this.lblLastName2Data);
            this.panel2.Controls.Add(this.lblContact2Data);
            this.panel2.Location = new System.Drawing.Point(31, 273);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(534, 146);
            this.panel2.TabIndex = 328;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Segoe Script", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(120, 429);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(333, 44);
            this.label25.TabIndex = 329;
            this.label25.Text = "Payment Information";
            this.label25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightCyan;
            this.panel3.Controls.Add(this.lblSecurityCode);
            this.panel3.Controls.Add(this.lblCreditCardType);
            this.panel3.Controls.Add(this.lblExpireYear);
            this.panel3.Controls.Add(this.lblExpireMonth);
            this.panel3.Controls.Add(this.lblDebitCreditCardNumber);
            this.panel3.Controls.Add(this.lblCardHolderName);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Location = new System.Drawing.Point(31, 474);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(539, 156);
            this.panel3.TabIndex = 330;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // lblSecurityCode
            // 
            this.lblSecurityCode.AutoSize = true;
            this.lblSecurityCode.Location = new System.Drawing.Point(205, 101);
            this.lblSecurityCode.Name = "lblSecurityCode";
            this.lblSecurityCode.Size = new System.Drawing.Size(0, 17);
            this.lblSecurityCode.TabIndex = 331;
            // 
            // ViewTripForTwo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(610, 639);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.lblCelebration);
            this.Controls.Add(this.lblLoggedInUserEmail);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ViewTripForTwo";
            this.Text = "ViewTripForTwo";
            this.Load += new System.EventHandler(this.ViewTripForTwo_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMidName2Lbl;
        private System.Windows.Forms.Label lblGender2Lbl;
        private System.Windows.Forms.Label lblDateBirth2Lbl;
        private System.Windows.Forms.Label lblFirstName2Lbl;
        private System.Windows.Forms.Label lblLastName2Lbl;
        private System.Windows.Forms.Label lblContact2Lbl;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblMidName2Data;
        private System.Windows.Forms.Label lblGender2Data;
        private System.Windows.Forms.Label lblDateBirth2Data;
        private System.Windows.Forms.Label lblFirstName2Data;
        private System.Windows.Forms.Label lblLastName2Data;
        private System.Windows.Forms.Label lblContact2Data;
        private System.Windows.Forms.Label lblDateOfTravel2;
        private System.Windows.Forms.Label lblDateOfTravel;
        private System.Windows.Forms.Label lblLoggedInUserEmail;
        private System.Windows.Forms.Label lblCreditCardType;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblExpireYear;
        private System.Windows.Forms.Label lblExpireMonth;
        private System.Windows.Forms.Label lblDebitCreditCardNumber;
        private System.Windows.Forms.Label lblCardHolderName;
        private System.Windows.Forms.Label lblMidName1Lbl;
        private System.Windows.Forms.Label lblGender1Lbl;
        private System.Windows.Forms.Label lblDateBirth1Lbl;
        private System.Windows.Forms.Label lblFirstName1Lbl;
        private System.Windows.Forms.Label lblLastName1Lbl;
        private System.Windows.Forms.Label lblContact1Lbl;
        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblMidName1Data;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblGender1Data;
        private System.Windows.Forms.Label lblDateBirth1Data;
        private System.Windows.Forms.Label lblFirstName1Data;
        private System.Windows.Forms.Label lblLastName1Data;
        private System.Windows.Forms.Label lblContact1Data;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCelebration;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblSecurityCode;
    }
}
﻿namespace VacationGetaways
{
    partial class Confirmation2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Confirmation2));
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblMiddleName2 = new System.Windows.Forms.Label();
            this.lblGender2 = new System.Windows.Forms.Label();
            this.lblBirthDate2 = new System.Windows.Forms.Label();
            this.lblFirstName2 = new System.Windows.Forms.Label();
            this.lblLastName2 = new System.Windows.Forms.Label();
            this.lblContactNumber2 = new System.Windows.Forms.Label();
            this.lblMiddleName = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblBirthDate = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblContactNumber = new System.Windows.Forms.Label();
            this.lblExpirationDate = new System.Windows.Forms.Label();
            this.lblDebitCreditCardNumber = new System.Windows.Forms.Label();
            this.lblCardHolderName = new System.Windows.Forms.Label();
            this.lblSecurityCode = new System.Windows.Forms.Label();
            this.lblResults = new System.Windows.Forms.Label();
            this.lblError1 = new System.Windows.Forms.Label();
            this.ckConfirm = new System.Windows.Forms.CheckBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this.lblCreditCardType = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblLoggedInUserEmail = new System.Windows.Forms.Label();
            this.lblDateOfTravel1 = new System.Windows.Forms.Label();
            this.lblDateOfTravel2 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lblCelebration = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblNondisclosure = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(53, 70);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 17);
            this.label8.TabIndex = 209;
            this.label8.Text = "Middle Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(87, 155);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 17);
            this.label9.TabIndex = 208;
            this.label9.Text = "Gender";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.ForeColor = System.Drawing.Color.DimGray;
            this.label11.Location = new System.Drawing.Point(56, 139);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 17);
            this.label11.TabIndex = 207;
            this.label11.Text = "Date of Birth";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.ForeColor = System.Drawing.Color.DimGray;
            this.label12.Location = new System.Drawing.Point(68, 47);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 17);
            this.label12.TabIndex = 206;
            this.label12.Text = "First Name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.ForeColor = System.Drawing.Color.DimGray;
            this.label13.Location = new System.Drawing.Point(68, 95);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 17);
            this.label13.TabIndex = 205;
            this.label13.Text = "Last Name";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.ForeColor = System.Drawing.Color.DimGray;
            this.label22.Location = new System.Drawing.Point(33, 111);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(110, 17);
            this.label22.TabIndex = 203;
            this.label22.Text = "Contact Number";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.ForeColor = System.Drawing.Color.DimGray;
            this.label10.Location = new System.Drawing.Point(56, 91);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 17);
            this.label10.TabIndex = 195;
            this.label10.Text = "Middle Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(88, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 194;
            this.label3.Text = "Gender";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(56, 157);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 17);
            this.label7.TabIndex = 193;
            this.label7.Text = "Date of Birth";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(69, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 17);
            this.label2.TabIndex = 192;
            this.label2.Text = "First Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(69, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 17);
            this.label5.TabIndex = 191;
            this.label5.Text = "Last Name";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.ForeColor = System.Drawing.Color.DimGray;
            this.label15.Location = new System.Drawing.Point(35, 134);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(110, 17);
            this.label15.TabIndex = 189;
            this.label15.Text = "Contact Number";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.ForeColor = System.Drawing.Color.DimGray;
            this.label16.Location = new System.Drawing.Point(134, 69);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(104, 17);
            this.label16.TabIndex = 174;
            this.label16.Text = "Expiration Date";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.ForeColor = System.Drawing.Color.DimGray;
            this.label18.Location = new System.Drawing.Point(73, 46);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(168, 17);
            this.label18.TabIndex = 171;
            this.label18.Text = "Debit/Credit card Number";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.ForeColor = System.Drawing.Color.DimGray;
            this.label19.Location = new System.Drawing.Point(122, 22);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(119, 17);
            this.label19.TabIndex = 170;
            this.label19.Text = "Cardholder Name";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.ForeColor = System.Drawing.Color.DimGray;
            this.label20.Location = new System.Drawing.Point(143, 90);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(96, 17);
            this.label20.TabIndex = 167;
            this.label20.Text = "Security Code";
            // 
            // lblMiddleName2
            // 
            this.lblMiddleName2.AutoSize = true;
            this.lblMiddleName2.BackColor = System.Drawing.Color.Transparent;
            this.lblMiddleName2.Location = new System.Drawing.Point(240, 362);
            this.lblMiddleName2.Name = "lblMiddleName2";
            this.lblMiddleName2.Size = new System.Drawing.Size(0, 17);
            this.lblMiddleName2.TabIndex = 223;
            this.lblMiddleName2.Click += new System.EventHandler(this.lblMiddleName2_Click);
            // 
            // lblGender2
            // 
            this.lblGender2.AutoSize = true;
            this.lblGender2.BackColor = System.Drawing.Color.Transparent;
            this.lblGender2.Location = new System.Drawing.Point(240, 447);
            this.lblGender2.Name = "lblGender2";
            this.lblGender2.Size = new System.Drawing.Size(0, 17);
            this.lblGender2.TabIndex = 222;
            this.lblGender2.Click += new System.EventHandler(this.lblGender2_Click);
            // 
            // lblBirthDate2
            // 
            this.lblBirthDate2.AutoSize = true;
            this.lblBirthDate2.BackColor = System.Drawing.Color.Transparent;
            this.lblBirthDate2.Location = new System.Drawing.Point(240, 423);
            this.lblBirthDate2.Name = "lblBirthDate2";
            this.lblBirthDate2.Size = new System.Drawing.Size(0, 17);
            this.lblBirthDate2.TabIndex = 221;
            this.lblBirthDate2.Click += new System.EventHandler(this.lblBirthDate2_Click);
            // 
            // lblFirstName2
            // 
            this.lblFirstName2.AutoSize = true;
            this.lblFirstName2.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstName2.Location = new System.Drawing.Point(240, 339);
            this.lblFirstName2.Name = "lblFirstName2";
            this.lblFirstName2.Size = new System.Drawing.Size(0, 17);
            this.lblFirstName2.TabIndex = 220;
            this.lblFirstName2.Click += new System.EventHandler(this.lblFirstName2_Click);
            // 
            // lblLastName2
            // 
            this.lblLastName2.AutoSize = true;
            this.lblLastName2.BackColor = System.Drawing.Color.Transparent;
            this.lblLastName2.Location = new System.Drawing.Point(240, 380);
            this.lblLastName2.Name = "lblLastName2";
            this.lblLastName2.Size = new System.Drawing.Size(0, 17);
            this.lblLastName2.TabIndex = 219;
            this.lblLastName2.Click += new System.EventHandler(this.lblLastName2_Click);
            // 
            // lblContactNumber2
            // 
            this.lblContactNumber2.AutoSize = true;
            this.lblContactNumber2.BackColor = System.Drawing.Color.Transparent;
            this.lblContactNumber2.Location = new System.Drawing.Point(240, 403);
            this.lblContactNumber2.Name = "lblContactNumber2";
            this.lblContactNumber2.Size = new System.Drawing.Size(0, 17);
            this.lblContactNumber2.TabIndex = 217;
            this.lblContactNumber2.Click += new System.EventHandler(this.lblContactNumber2_Click);
            // 
            // lblMiddleName
            // 
            this.lblMiddleName.AutoSize = true;
            this.lblMiddleName.BackColor = System.Drawing.Color.Transparent;
            this.lblMiddleName.Location = new System.Drawing.Point(240, 143);
            this.lblMiddleName.Name = "lblMiddleName";
            this.lblMiddleName.Size = new System.Drawing.Size(0, 17);
            this.lblMiddleName.TabIndex = 216;
            this.lblMiddleName.Click += new System.EventHandler(this.lblMiddleName_Click);
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.BackColor = System.Drawing.Color.Transparent;
            this.lblGender.Location = new System.Drawing.Point(240, 234);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(0, 17);
            this.lblGender.TabIndex = 215;
            this.lblGender.Click += new System.EventHandler(this.lblGender_Click);
            // 
            // lblBirthDate
            // 
            this.lblBirthDate.AutoSize = true;
            this.lblBirthDate.BackColor = System.Drawing.Color.Transparent;
            this.lblBirthDate.Location = new System.Drawing.Point(240, 209);
            this.lblBirthDate.Name = "lblBirthDate";
            this.lblBirthDate.Size = new System.Drawing.Size(0, 17);
            this.lblBirthDate.TabIndex = 214;
            this.lblBirthDate.Click += new System.EventHandler(this.lblBirthDate_Click);
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstName.Location = new System.Drawing.Point(240, 119);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(0, 17);
            this.lblFirstName.TabIndex = 213;
            this.lblFirstName.Click += new System.EventHandler(this.lblFirstName_Click);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.BackColor = System.Drawing.Color.Transparent;
            this.lblLastName.Location = new System.Drawing.Point(240, 166);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(0, 17);
            this.lblLastName.TabIndex = 212;
            this.lblLastName.Click += new System.EventHandler(this.lblLastName_Click);
            // 
            // lblContactNumber
            // 
            this.lblContactNumber.AutoSize = true;
            this.lblContactNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblContactNumber.Location = new System.Drawing.Point(240, 186);
            this.lblContactNumber.Name = "lblContactNumber";
            this.lblContactNumber.Size = new System.Drawing.Size(0, 17);
            this.lblContactNumber.TabIndex = 210;
            this.lblContactNumber.Click += new System.EventHandler(this.lblContactNumber_Click);
            // 
            // lblExpirationDate
            // 
            this.lblExpirationDate.AutoSize = true;
            this.lblExpirationDate.BackColor = System.Drawing.Color.Transparent;
            this.lblExpirationDate.Location = new System.Drawing.Point(325, 614);
            this.lblExpirationDate.Name = "lblExpirationDate";
            this.lblExpirationDate.Size = new System.Drawing.Size(0, 17);
            this.lblExpirationDate.TabIndex = 227;
            this.lblExpirationDate.Click += new System.EventHandler(this.lblExpirationDate_Click);
            // 
            // lblDebitCreditCardNumber
            // 
            this.lblDebitCreditCardNumber.AutoSize = true;
            this.lblDebitCreditCardNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblDebitCreditCardNumber.Location = new System.Drawing.Point(325, 590);
            this.lblDebitCreditCardNumber.Name = "lblDebitCreditCardNumber";
            this.lblDebitCreditCardNumber.Size = new System.Drawing.Size(0, 17);
            this.lblDebitCreditCardNumber.TabIndex = 226;
            this.lblDebitCreditCardNumber.Click += new System.EventHandler(this.lblDebitCreditCardNumber_Click);
            // 
            // lblCardHolderName
            // 
            this.lblCardHolderName.AutoSize = true;
            this.lblCardHolderName.BackColor = System.Drawing.Color.Transparent;
            this.lblCardHolderName.Location = new System.Drawing.Point(325, 566);
            this.lblCardHolderName.Name = "lblCardHolderName";
            this.lblCardHolderName.Size = new System.Drawing.Size(0, 17);
            this.lblCardHolderName.TabIndex = 225;
            this.lblCardHolderName.Click += new System.EventHandler(this.lblCardHolderName_Click);
            // 
            // lblSecurityCode
            // 
            this.lblSecurityCode.AutoSize = true;
            this.lblSecurityCode.BackColor = System.Drawing.Color.Transparent;
            this.lblSecurityCode.Location = new System.Drawing.Point(325, 634);
            this.lblSecurityCode.Name = "lblSecurityCode";
            this.lblSecurityCode.Size = new System.Drawing.Size(0, 17);
            this.lblSecurityCode.TabIndex = 224;
            this.lblSecurityCode.Click += new System.EventHandler(this.lblSecurityCode_Click);
            // 
            // lblResults
            // 
            this.lblResults.BackColor = System.Drawing.Color.Transparent;
            this.lblResults.Location = new System.Drawing.Point(405, 64);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(195, 131);
            this.lblResults.TabIndex = 228;
            this.lblResults.Click += new System.EventHandler(this.lblResults_Click);
            // 
            // lblError1
            // 
            this.lblError1.AutoSize = true;
            this.lblError1.BackColor = System.Drawing.Color.Transparent;
            this.lblError1.ForeColor = System.Drawing.Color.Red;
            this.lblError1.Location = new System.Drawing.Point(73, 176);
            this.lblError1.Name = "lblError1";
            this.lblError1.Size = new System.Drawing.Size(460, 17);
            this.lblError1.TabIndex = 232;
            this.lblError1.Text = "Must checkbox to continue, otherwise click \"Back\" to change information";
            // 
            // ckConfirm
            // 
            this.ckConfirm.AutoSize = true;
            this.ckConfirm.BackColor = System.Drawing.Color.Khaki;
            this.ckConfirm.Location = new System.Drawing.Point(139, 706);
            this.ckConfirm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ckConfirm.Name = "ckConfirm";
            this.ckConfirm.Size = new System.Drawing.Size(419, 21);
            this.ckConfirm.TabIndex = 231;
            this.ckConfirm.Text = "The information information and package selected are correct";
            this.ckConfirm.UseVisualStyleBackColor = false;
            this.ckConfirm.CheckedChanged += new System.EventHandler(this.ckConfirm_CheckedChanged);
            // 
            // btnCreate
            // 
            this.btnCreate.BackColor = System.Drawing.Color.LightCyan;
            this.btnCreate.Enabled = false;
            this.btnCreate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreate.ForeColor = System.Drawing.Color.LightCoral;
            this.btnCreate.Location = new System.Drawing.Point(460, 797);
            this.btnCreate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(206, 28);
            this.btnCreate.TabIndex = 229;
            this.btnCreate.Text = "Create New Trip";
            this.btnCreate.UseVisualStyleBackColor = false;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // lblCreditCardType
            // 
            this.lblCreditCardType.AutoSize = true;
            this.lblCreditCardType.BackColor = System.Drawing.Color.Transparent;
            this.lblCreditCardType.Location = new System.Drawing.Point(325, 659);
            this.lblCreditCardType.Name = "lblCreditCardType";
            this.lblCreditCardType.Size = new System.Drawing.Size(0, 17);
            this.lblCreditCardType.TabIndex = 234;
            this.lblCreditCardType.Click += new System.EventHandler(this.lblCreditCardType_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(127, 114);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 17);
            this.label6.TabIndex = 233;
            this.label6.Text = "Credit Card Type";
            // 
            // lblLoggedInUserEmail
            // 
            this.lblLoggedInUserEmail.AutoSize = true;
            this.lblLoggedInUserEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblLoggedInUserEmail.ForeColor = System.Drawing.Color.Red;
            this.lblLoggedInUserEmail.Location = new System.Drawing.Point(206, 11);
            this.lblLoggedInUserEmail.Name = "lblLoggedInUserEmail";
            this.lblLoggedInUserEmail.Size = new System.Drawing.Size(0, 17);
            this.lblLoggedInUserEmail.TabIndex = 235;
            // 
            // lblDateOfTravel1
            // 
            this.lblDateOfTravel1.AutoSize = true;
            this.lblDateOfTravel1.BackColor = System.Drawing.Color.Transparent;
            this.lblDateOfTravel1.ForeColor = System.Drawing.Color.DimGray;
            this.lblDateOfTravel1.Location = new System.Drawing.Point(12, 22);
            this.lblDateOfTravel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDateOfTravel1.Name = "lblDateOfTravel1";
            this.lblDateOfTravel1.Size = new System.Drawing.Size(112, 17);
            this.lblDateOfTravel1.TabIndex = 236;
            this.lblDateOfTravel1.Text = "Date Of Booking";
            // 
            // lblDateOfTravel2
            // 
            this.lblDateOfTravel2.AutoSize = true;
            this.lblDateOfTravel2.BackColor = System.Drawing.Color.Transparent;
            this.lblDateOfTravel2.Location = new System.Drawing.Point(206, 74);
            this.lblDateOfTravel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDateOfTravel2.Name = "lblDateOfTravel2";
            this.lblDateOfTravel2.Size = new System.Drawing.Size(0, 17);
            this.lblDateOfTravel2.TabIndex = 237;
            this.lblDateOfTravel2.Click += new System.EventHandler(this.lblDateOfTravel2_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Segoe Script", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(173, 509);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(333, 44);
            this.label25.TabIndex = 238;
            this.label25.Text = "Payment Information";
            this.label25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCelebration
            // 
            this.lblCelebration.AutoSize = true;
            this.lblCelebration.BackColor = System.Drawing.Color.Transparent;
            this.lblCelebration.Font = new System.Drawing.Font("Segoe Script", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCelebration.ForeColor = System.Drawing.Color.Black;
            this.lblCelebration.Location = new System.Drawing.Point(173, 7);
            this.lblCelebration.Name = "lblCelebration";
            this.lblCelebration.Size = new System.Drawing.Size(341, 44);
            this.lblCelebration.TabIndex = 239;
            this.lblCelebration.Text = "Customer Information";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe Script", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(409, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 44);
            this.label1.TabIndex = 242;
            this.label1.Text = "Traveler 1 ";
            // 
            // lblNondisclosure
            // 
            this.lblNondisclosure.AutoSize = true;
            this.lblNondisclosure.BackColor = System.Drawing.Color.Transparent;
            this.lblNondisclosure.Font = new System.Drawing.Font("Imprint MT Shadow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNondisclosure.ForeColor = System.Drawing.Color.Red;
            this.lblNondisclosure.Location = new System.Drawing.Point(57, 796);
            this.lblNondisclosure.Name = "lblNondisclosure";
            this.lblNondisclosure.Size = new System.Drawing.Size(321, 24);
            this.lblNondisclosure.TabIndex = 241;
            this.lblNondisclosure.Text = "Your information will not be shared. ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightCyan;
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.lblResults);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lblDateOfTravel1);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Location = new System.Drawing.Point(46, 52);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(620, 214);
            this.panel1.TabIndex = 243;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightCyan;
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Location = new System.Drawing.Point(46, 292);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(620, 214);
            this.panel2.TabIndex = 243;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Segoe Script", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(409, 24);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(184, 44);
            this.label24.TabIndex = 240;
            this.label24.Text = "Traveler 2 ";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightCyan;
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.lblError1);
            this.panel3.Location = new System.Drawing.Point(46, 546);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(620, 214);
            this.panel3.TabIndex = 244;
            // 
            // Confirmation2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(725, 840);
            this.Controls.Add(this.lblMiddleName2);
            this.Controls.Add(this.lblGender2);
            this.Controls.Add(this.lblBirthDate2);
            this.Controls.Add(this.lblLastName2);
            this.Controls.Add(this.lblContactNumber2);
            this.Controls.Add(this.lblFirstName2);
            this.Controls.Add(this.lblMiddleName);
            this.Controls.Add(this.lblGender);
            this.Controls.Add(this.lblBirthDate);
            this.Controls.Add(this.lblFirstName);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.lblContactNumber);
            this.Controls.Add(this.lblDateOfTravel2);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.lblCelebration);
            this.Controls.Add(this.lblNondisclosure);
            this.Controls.Add(this.lblLoggedInUserEmail);
            this.Controls.Add(this.lblCreditCardType);
            this.Controls.Add(this.ckConfirm);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.lblExpirationDate);
            this.Controls.Add(this.lblDebitCreditCardNumber);
            this.Controls.Add(this.lblCardHolderName);
            this.Controls.Add(this.lblSecurityCode);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximumSize = new System.Drawing.Size(743, 1609);
            this.MinimumSize = new System.Drawing.Size(743, 768);
            this.Name = "Confirmation2";
            this.Text = "Confirmation2";
            this.Load += new System.EventHandler(this.Confirmation2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblMiddleName2;
        private System.Windows.Forms.Label lblGender2;
        private System.Windows.Forms.Label lblBirthDate2;
        private System.Windows.Forms.Label lblFirstName2;
        private System.Windows.Forms.Label lblLastName2;
        private System.Windows.Forms.Label lblContactNumber2;
        private System.Windows.Forms.Label lblMiddleName;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblBirthDate;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblContactNumber;
        private System.Windows.Forms.Label lblExpirationDate;
        private System.Windows.Forms.Label lblDebitCreditCardNumber;
        private System.Windows.Forms.Label lblCardHolderName;
        private System.Windows.Forms.Label lblSecurityCode;
        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.Label lblError1;
        private System.Windows.Forms.CheckBox ckConfirm;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Label lblCreditCardType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblLoggedInUserEmail;
        private System.Windows.Forms.Label lblDateOfTravel1;
        private System.Windows.Forms.Label lblDateOfTravel2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lblCelebration;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblNondisclosure;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label24;
    }
}
﻿public class Globals
{
    public static bool aUserIsLoggedIn;
    public static string loggedInUsersName;
    public static string loggedInUsersEmail;
    public static string loggedInUsersPassword;
    public static string currentSelectedTrip;
    public static string currentSelectedAirfare;
    public static string currentSelectedHotelCost;
    public static int currentSelectedNumOfPeople;
    public static int tripViewSelectedTripIndex;

}
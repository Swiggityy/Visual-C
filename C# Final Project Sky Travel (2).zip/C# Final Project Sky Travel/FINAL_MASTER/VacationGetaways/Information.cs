﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VacationGetaways
{
    public class Information
    {
        private string data1;
        private string data2;
        private string data3;
        private string data4;
        private string data5;
        private string data6;
        private string data7;
        private string data8;
        private string data9;
        private string data10;
        private string data11;
        private string data12;
        private string data13;
        private string data14;
        private string data15;

        public string Data1
        {
            get { return data1; }
            set { data1 = value; }
        }

        public string Data2
        {
            get { return data2; }
            set { data2 = value; }
        }
        public string Data3
        {
            get { return data3; }
            set { data3 = value; }
        }
        public string Data4
        {
            get { return data4; }
            set { data4 = value; }
        }
        public string Data5
        {
            get { return data5; }
            set { data5 = value; }
        }
        public string Data6
        {
            get { return data6; }
            set { data6 = value; }
        }
        public string Data7
        {
            get { return data7; }
            set { data7 = value; }
        }
        public string Data8
        {
            get { return data8; }
            set { data8 = value; }
        }
        public string Data9
        {
            get { return data9; }
            set { data9 = value; }
        }
        public string Data10
        {
            get { return data10; }
            set { data10 = value; }
        }
        public string Data11
        {
            get { return data11; }
            set { data11 = value; }
        }
        public string Data12
        {
            get { return data12; }
            set { data12 = value; }
        }
        public string Data13
        {
            get { return data13; }
            set { data13 = value; }
        }
        public string Data14
        {
            get { return data14; }
            set { data14 = value; }
        }
        public string Data15
        {
            get { return data15; }
            set { data15 = value; }
        }
    }
}

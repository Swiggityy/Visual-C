﻿using System;
/* Created by: Chris Nguyen
 * Created on: 1-23-18
 * Program: First program*/

namespace FirstProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            // Input from user
            Console.Write("Enter your hours worked: ");
            Console.ReadLine();
            Console.Write("Enter your hourly wage: ");
            Console.ReadLine();

            // Calculate what their pay is

            //Display to user
        }
    }
}

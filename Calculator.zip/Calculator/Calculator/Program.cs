﻿using System;
//Created by Chris Nguyen
namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            double quantity;
            double stamp;
            const int STAMP_COST = 3;

            Console.WriteLine("Enter amount of stamps");
            quantity = Convert.ToDouble(Console.ReadLine());

            stamp = STAMP_COST * quantity;

            Console.WriteLine("Your total cost is " + stamp);



        }
    }
}

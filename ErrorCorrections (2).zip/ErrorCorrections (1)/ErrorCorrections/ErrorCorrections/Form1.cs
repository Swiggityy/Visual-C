﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ErrorCorrections
{
	public partial class frmCustomer : Form
	{
		public frmCustomer()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			// Declare variables
			string firstName, lastName;

			// input data from user
			firstName = txtFirstName.Text;
			lastName = txtLastName.Text;

			//register or not
			if (chkRegister.Checked)
				lblMessage.Text = "Thankyou for registering with us";
			else
			lblMessage.Text = "Hello";
		}

		private void lblFirstName_Click(object sender, EventArgs e)
		{

		}
	}
}

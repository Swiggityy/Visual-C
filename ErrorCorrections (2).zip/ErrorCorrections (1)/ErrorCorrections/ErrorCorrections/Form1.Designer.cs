﻿namespace ErrorCorrections
{
    partial class frmCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.lblFirstName = new System.Windows.Forms.Label();
			this.lblLastName = new System.Windows.Forms.Label();
			this.lblMessage = new System.Windows.Forms.Label();
			this.txtFirstName = new System.Windows.Forms.TextBox();
			this.txtLastName = new System.Windows.Forms.TextBox();
			this.btnRecord = new System.Windows.Forms.Button();
			this.chkRegister = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// lblFirstName
			// 
			this.lblFirstName.AutoSize = true;
			this.lblFirstName.Location = new System.Drawing.Point(9, 43);
			this.lblFirstName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblFirstName.Name = "lblFirstName";
			this.lblFirstName.Size = new System.Drawing.Size(85, 13);
			this.lblFirstName.TabIndex = 0;
			this.lblFirstName.Text = "Enter First Name";
			this.lblFirstName.Click += new System.EventHandler(this.lblFirstName_Click);
			// 
			// lblLastName
			// 
			this.lblLastName.AutoSize = true;
			this.lblLastName.Location = new System.Drawing.Point(9, 93);
			this.lblLastName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblLastName.Name = "lblLastName";
			this.lblLastName.Size = new System.Drawing.Size(86, 13);
			this.lblLastName.TabIndex = 1;
			this.lblLastName.Text = "Enter Last Name";
			// 
			// lblMessage
			// 
			this.lblMessage.AutoSize = true;
			this.lblMessage.Location = new System.Drawing.Point(95, 218);
			this.lblMessage.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblMessage.Name = "lblMessage";
			this.lblMessage.Size = new System.Drawing.Size(0, 13);
			this.lblMessage.TabIndex = 2;
			// 
			// txtFirstName
			// 
			this.txtFirstName.Location = new System.Drawing.Point(110, 43);
			this.txtFirstName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.txtFirstName.Name = "txtFirstName";
			this.txtFirstName.Size = new System.Drawing.Size(76, 20);
			this.txtFirstName.TabIndex = 3;
			// 
			// txtLastName
			// 
			this.txtLastName.Location = new System.Drawing.Point(110, 93);
			this.txtLastName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.txtLastName.Name = "txtLastName";
			this.txtLastName.Size = new System.Drawing.Size(76, 20);
			this.txtLastName.TabIndex = 4;
			// 
			// btnRecord
			// 
			this.btnRecord.Location = new System.Drawing.Point(62, 174);
			this.btnRecord.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.btnRecord.Name = "btnRecord";
			this.btnRecord.Size = new System.Drawing.Size(98, 19);
			this.btnRecord.TabIndex = 5;
			this.btnRecord.Text = "Press to Record";
			this.btnRecord.UseVisualStyleBackColor = true;
			this.btnRecord.Click += new System.EventHandler(this.button1_Click);
			// 
			// chkRegister
			// 
			this.chkRegister.AutoSize = true;
			this.chkRegister.Checked = true;
			this.chkRegister.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkRegister.Location = new System.Drawing.Point(98, 135);
			this.chkRegister.Name = "chkRegister";
			this.chkRegister.Size = new System.Drawing.Size(101, 17);
			this.chkRegister.TabIndex = 6;
			this.chkRegister.Text = "Register with us";
			this.chkRegister.UseVisualStyleBackColor = true;
			// 
			// frmCustomer
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(243, 240);
			this.Controls.Add(this.chkRegister);
			this.Controls.Add(this.btnRecord);
			this.Controls.Add(this.txtLastName);
			this.Controls.Add(this.txtFirstName);
			this.Controls.Add(this.lblMessage);
			this.Controls.Add(this.lblLastName);
			this.Controls.Add(this.lblFirstName);
			this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.Name = "frmCustomer";
			this.Text = "Customer Information";
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Button btnRecord;
		private System.Windows.Forms.CheckBox chkRegister;
	}
}

